// Variáveis principais do jogo
let truck;                          // Caminhão controlado pelo jogador
let obstacles = [];                // Lista de obstáculos
let fruits = [];                   // Lista de frutas
let score = 0;                     // Pontuação atual
let speed = 2;                     // Velocidade base dos objetos
let scene = 1;                     // Fase atual
let maxScenes = 6;                // Número máximo de fases normais
let gameOver = false;             // Indica se o jogador perdeu
let gameWon = false;              // Indica se o jogador venceu

// Emojis usados como frutas e obstáculos
let frutaEmojis = ["🍎", "🍌", "🍍", "🍇", "🥕"];              // Emojis das frutas
let obstaculosEmoji = ["🗑️", "🚒", "🚧", "🕳️", "🛢️"];         // Emojis dos obstáculos

// Controle de fases bônus
let partidasJogadas = 0;          // Conta quantas partidas foram jogadas
let faseBonus = false;            // Indica se está na fase bônus

// Controle da mensagem de aviso de fase bônus
let avisoFaseBonus = false;       // Mostra mensagem de entrada da fase bônus
let avisoTempo = 0;               // Temporizador da mensagem de aviso
let avisoDuracao = 180;           // Duração da mensagem (3 segundos a 60 FPS)

// Função principal de configuração
function setup() {
  createCanvas(400, 600);         // Cria o canvas de 400x600 pixels
  textAlign(CENTER, CENTER);      // Alinha o texto ao centro
  resetGame();                    // Inicia ou reinicia o jogo
}

// Função principal de desenho que roda a cada frame
function draw() {
  // Mostra aviso de fase bônus antes de iniciar
  if (avisoFaseBonus) {
    background(50, 150, 255);                             // Fundo azul
    fill(255);                                            // Texto branco
    textSize(48);
    text("🚀 Fase Bônus! 🚀", width / 2, height / 2);      // Mensagem da fase bônus
    avisoTempo++;                                         // Incrementa o tempo do aviso
    if (avisoTempo > avisoDuracao) {                      // Se passou o tempo, inicia fase bônus
      avisoFaseBonus = false;
      avisoTempo = 0;
      resetForBonus();
    }
    return;
  }

  // Tela de game over
  if (gameOver) {
    background(0);                                        // Fundo preto
    fill(255);
    textSize(32);
    text("💥 Você bateu! 💥", width / 2, height / 2 - 20); // Mensagem de derrota
    textSize(24);
    text("Pontuação: " + score, width / 2, height / 2 + 20); // Mostra a pontuação
    textSize(18);
    text("Pressione ESPAÇO para jogar novamente", width / 2, height / 2 + 60);
    return;
  }

  // Tela de vitória
  if (gameWon) {
    background(200, 255, 200);                            // Fundo verde claro
    fill(0);
    textSize(32);
    text(faseBonus ? "🎉 Você conseguiu! 🎉" : "🏁 Você completou o caminho! 🏁", width / 2, height / 2 - 20);
    textSize(24);
    text("Pontuação final: " + score, width / 2, height / 2 + 20);
    textSize(18);
    text("Pressione ESPAÇO para jogar novamente", width / 2, height / 2 + 60);
    return;
  }

  drawScene();                // Desenha o fundo da cena

  truck.show();               // Desenha o caminhão
  truck.move();               // Move o caminhão

  // Cria obstáculos apenas fora da fase bônus
  if (!faseBonus) {
    if (frameCount % 60 === 0 && score < maxScenes * 10) {
      obstacles.push(new Obstacle()); // Adiciona novo obstáculo a cada segundo
    }
  }

  // Define intervalo entre frutas (mais rápido na fase bônus)
  let frutaInterval = faseBonus ? 60 : 180;
  if (frameCount % frutaInterval === 0 && (faseBonus || score < maxScenes * 10)) {
    fruits.push(new Fruit()); // Adiciona nova fruta
  }

  // Atualiza e desenha os obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();      // Move o obstáculo
    obstacles[i].show();        // Desenha o obstáculo

    if (obstacles[i].hits(truck)) { // Verifica colisão com caminhão
      gameOver = true;              // Fim de jogo
    }

    if (obstacles[i].offscreen()) { // Saiu da tela
      obstacles.splice(i, 1);       // Remove obstáculo
      score++;                      // Aumenta pontuação

      // Aumenta fase e velocidade a cada 10 pontos
      if (!faseBonus && score % 10 === 0 && scene < maxScenes) {
        scene++;
        speed += 1;
      }
    }
  }

  // Atualiza e desenha as frutas
  for (let i = fruits.length - 1; i >= 0; i--) {
    fruits[i].update();         // Move a fruta
    fruits[i].show();           // Desenha a fruta

    if (fruits[i].hits(truck)) {  // Pegou a fruta
      score += 3;                // Ganha 3 pontos
      fruits.splice(i, 1);       // Remove fruta
    } else if (fruits[i].offscreen()) { // Saiu da tela
      fruits.splice(i, 1);             // Remove
    }
  }

  // Condição de vitória normal
  if (!faseBonus && score >= maxScenes * 10) {
    gameWon = true;
  }

  // Condição de vitória na fase bônus
  if (faseBonus && score >= 60) {
    gameWon = true;
  }

  // Mostra pontuação e fase na tela
  fill(0);
  textSize(20);
  text("Pontos: " + score, width - 70, 30);
  textSize(20);
  text("Fase: " + (faseBonus ? "Bônus" : scene), 70, 30);
}

// Define o fundo da fase atual
function drawScene() {
  if (faseBonus) {
    background(135, 206, 250); // Azul claro na fase bônus
  } else if (scene < 3) {
    background(210, 180, 140); // Marrom claro nas fases iniciais
  } else {
    background(60);            // Escuro nas fases finais
  }
}

// Classe do caminhão (jogador)
class Truck {
  constructor() {
    this.x = width / 2;   // Posição inicial
    this.size = 50;
  }

  show() {
    textSize(40);
    text("🚚", this.x, height - 50); // Desenha caminhão
  }

  move() {
    let velocidade = faseBonus ? 8 : 5; // Mais rápido na fase bônus
    if (keyIsDown(LEFT_ARROW)) this.x -= velocidade;   // Move esquerda
    if (keyIsDown(RIGHT_ARROW)) this.x += velocidade;  // Move direita
    this.x = constrain(this.x, 20, width - 20);         // Limita movimento
  }
}

// Classe dos obstáculos
class Obstacle {
  constructor() {
    this.x = random(20, width - 20);   // Posição aleatória
    this.y = 0;
    this.emoji = random(obstaculosEmoji); // Escolhe emoji aleatório
  }

  update() {
    this.y += speed; // Move para baixo
  }

  show() {
    textSize(32);
    text(this.emoji, this.x, this.y); // Desenha obstáculo
  }

  hits(truck) {
    return dist(this.x, this.y, truck.x, height - 50) < 40; // Detecta colisão
  }

  offscreen() {
    return this.y > height; // Verifica se saiu da tela
  }
}

// Classe das frutas
class Fruit {
  constructor() {
    this.x = random(20, width - 20);    // Posição aleatória
    this.y = 0;
    this.emoji = random(frutaEmojis);   // Escolhe emoji aleatório
  }

  update() {
    this.y += speed; // Move para baixo
  }

  show() {
    textSize(28);
    text(this.emoji, this.x, this.y); // Desenha fruta
  }

  hits(truck) {
    return dist(this.x, this.y, truck.x, height - 50) < 35; // Detecta colisão com caminhão
  }

  offscreen() {
    return this.y > height; // Verifica se saiu da tela
  }
}

// Reinicia o jogo ao pressionar espaço
function keyPressed() {
  if (key === ' ') {
    resetGame();
  }
}

// Reinicia o jogo normal
function resetGame() {
  partidasJogadas++;           // Incrementa contador de partidas

  if (partidasJogadas % 2 === 0) {
    avisoFaseBonus = true;     // Mostra aviso de fase bônus
    faseBonus = false;
  } else {
    faseBonus = false;
  }

  truck = new Truck();         // Cria novo caminhão
  obstacles = [];              // Limpa obstáculos
  fruits = [];                 // Limpa frutas
  score = 0;                   // Zera pontuação
  speed = 9;                   // Reinicia velocidade
  scene = 1;                   // Volta para fase 1
  gameOver = false;
  gameWon = false;
}

// Reinicia o jogo para a fase bônus
function resetForBonus() {
  faseBonus = true;
  obstacles = [];              // Limpa obstáculos
  fruits = [];                 // Limpa frutas
  score = 0;                   // Zera pontuação
  speed = 10;                  // Velocidade aumentada
  scene = 1;                   // Mostra como fase 1 (mas é bônus)
  gameOver = false;
  gameWon = false;
}
